var modal = document.getElementById("modalPhotos");
var span = document.getElementsByClassName("close")[0];
var photos = document.getElementsByClassName("thumbnail");
var email = document.getElementById("emailId");

// photos.forEach(element => {              // czemu to tu nie chce dzialac???!?!?!?!?
//     element.onclick=function(){
//         modal.style.display="block";
//     }
// });

var i;
for (i = 0; i < photos.length; i++) {
    photos[i].onclick=function(){
        modal.style.display="block";   //otwarcie modala
    }
}

span.onclick=function(){
    modal.style.display="none";  //zamkniecie modala
}

window.onclick=function(event){
    if(event.target==modal){   // nie rozumiem !!!!!!!!!!!!!!!
        modal.style.display = "none";  //zamkniecie modala gdy klik poza modal
    }
}